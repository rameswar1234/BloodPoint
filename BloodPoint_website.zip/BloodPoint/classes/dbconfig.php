<?php
    define('host','localhost');
    define('name','root');
    define('pass','');
    define('dbname','bloodpoint');
?>